# Cómo publicar tu página con panel privado

Esto te va a dejar con:
- Tu página pública en internet (con tu dominio si quieres).
- Un panel privado en `tupagina.com/admin` donde solo tú puedes entrar (con tu correo y contraseña) para cambiar textos, fotos y servicios, sin tocar código.

Es gratis (con las cuentas gratuitas de GitHub y Netlify). Tarda unos 15-20 minutos la primera vez. Después de esto, cada cambio que hagas en el panel se publica solo, en 1-2 minutos.

---

## Paso 1: Crear cuenta en GitHub
1. Ve a https://github.com y crea una cuenta gratuita.
2. Crea un repositorio nuevo (botón verde "New"). Ponle de nombre, por ejemplo, `vam-constructora`. Puede ser privado o público, no importa.
3. Sube TODOS los archivos y carpetas de esta entrega (`index.html`, `content.json`, la carpeta `images/`, la carpeta `admin/`) a ese repositorio. Puedes arrastrarlos directamente desde tu computadora en la página de GitHub ("Add file" → "Upload files").

## Paso 2: Conectar con Netlify
1. Ve a https://netlify.com y crea una cuenta gratuita (puedes entrar con tu cuenta de GitHub directamente).
2. Click en "Add new site" → "Import an existing project" → elige GitHub → selecciona el repositorio `vam-constructora`.
3. Déjalo con la configuración que te proponga y dale "Deploy". En un par de minutos tu página ya estará viva en una dirección tipo `algo-al-azar.netlify.app`.
   - Si quieres tu propio dominio (como `vamconstructora.com`), en Netlify ve a "Domain settings" y sigue los pasos para conectarlo. Esto normalmente tiene un costo aparte (el dominio en sí, no Netlify).

## Paso 3: Activar el login privado (Netlify Identity)
1. Dentro de tu sitio en Netlify, ve a la pestaña **"Identity"** y dale **"Enable Identity"**.
2. Baja a **"Registration"** y cámbialo a **"Invite only"** (así nadie más se puede registrar, solo tú).
3. Baja a **"Services"** → activa **"Git Gateway"** (dale "Enable Git Gateway").
4. Regresa a la pestaña **"Identity"** y dale a **"Invite users"** — escribe tu correo y mándate la invitación.
5. Revisa tu correo, acepta la invitación y crea tu contraseña.

## Paso 4: Entrar a tu panel
1. Ve a `tudominio.netlify.app/admin` (o `tudominio.com/admin` si ya conectaste tu dominio).
2. Inicia sesión con el correo y contraseña que creaste.
3. Ahí puedes editar: la portada, los servicios, la galería de trabajos, la sección "Nosotros" y los datos de contacto — todo con formularios, sin código.
4. Cuando guardas un cambio, la página se actualiza sola en 1-2 minutos.

---

### Sobre seguridad
- Solo las personas que tú invites por correo (Paso 3.4) pueden entrar al panel — nadie más, aunque conozcan la dirección `/admin`.
- Para protección extra contra ataques (bots, tráfico raro, etc.), puedes activar **Cloudflare** (gratis) apuntando tu dominio ahí — te avisa de tráfico sospechoso y filtra bots automáticamente. Si quieres, en otro momento te ayudo a configurarlo.

### Sobre saber quién visita / quién es cliente interesado
Este panel resuelve la parte de "solo yo puedo editar". Para lo de **rastrear visitas y guardar datos de clientes interesados** (lo que mencionaste antes), es un paso aparte — cuando quieras lo armamos: normalmente se hace agregando un formulario de contacto conectado a una base de datos o a tu correo, más una herramienta de analítica gratuita (Google Analytics o Plausible) para ver cuánta gente visita y desde dónde.
